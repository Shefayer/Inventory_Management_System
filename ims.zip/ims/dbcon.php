<?php
$servername = "localhost";
$username = "root"; 
$password ="";  
$dbname ="ims"; 

$conn = new mysqli($servername,$username,$password,$dbname); 
?>